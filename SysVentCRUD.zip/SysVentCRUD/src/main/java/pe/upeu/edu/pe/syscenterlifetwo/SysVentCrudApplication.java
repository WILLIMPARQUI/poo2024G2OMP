package pe.upeu.edu.pe.syscenterlifetwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysVentCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysVentCrudApplication.class, args);
	}

}
