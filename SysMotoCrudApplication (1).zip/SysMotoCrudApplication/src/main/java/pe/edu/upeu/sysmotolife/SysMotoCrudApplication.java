package pe.edu.upeu.sysmotolife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysMotoCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysMotoCrudApplication.class, args);
	}

}
