package pe.edu.upeui.syscenterlife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysVuelosApplicationTests {

	@Test
	void contextLoads() {
	}

}
