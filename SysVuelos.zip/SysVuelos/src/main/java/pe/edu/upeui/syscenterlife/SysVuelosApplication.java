package pe.edu.upeui.syscenterlife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysVuelosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysVuelosApplication.class, args);
	}

}
